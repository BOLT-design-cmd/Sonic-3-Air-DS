#include <nds.h>
#include <fat.h>
#include <stdio.h>

#define ROM_PATH "/Sonic 3 Air/Sonic_Knuckles_wSonic3.bin"

int main(void) {
    consoleDemoInit();
    bool fatReady = FATInitDefault();
    FILE *rom = fatReady ? fopen(ROM_PATH, "rb") : NULL;

    consoleClear();
    iprintf("Sonic 3 A.I.R. DS v1 prototype\n\n");

    if (!fatReady || !rom) {
        iprintf("Sonic 3 and Knuckles Steam ROM not found.\n\n");
        iprintf("Please create a folder named\n");
        iprintf("\"Sonic 3 Air\" in the root of\n");
        iprintf("your SD card and place the Sonic\n");
        iprintf("3 and Knuckles Steam ROM file inside it.\n\n");
        iprintf("Expected file:\n%s\n", ROM_PATH);
    } else {
        iprintf("ROM file detected.\n\n");
        iprintf("This prototype does not yet\n");
        iprintf("contain a game engine to run it.\n");
        fclose(rom);
    }

    iprintf("\nButton mapping target:\n");
    iprintf("AIR B -> DS A\nAIR A -> DS B\n");
    iprintf("AIR X -> DS Y\nAIR Y -> DS X\n");

    while (1) swiWaitForVBlank();
    return 0;
}
