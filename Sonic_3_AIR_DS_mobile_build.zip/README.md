# Sonic 3 A.I.R. DS — v1 prototype

Target: Nintendo DSi homebrew.

Expected SD-card file:
`/Sonic 3 Air/Sonic_Knuckles_wSonic3.bin`

If the file is missing, the prototype displays an English prompt.
If detected, it reports detection only. A game engine to process/run the commercial game data is not included.

Planned button mapping:
- AIR B -> DS A
- AIR A -> DS B
- AIR X -> DS Y
- AIR Y -> DS X

Build requirements: devkitPro, devkitARM, libnds, libfat.
Run `make` in the devkitPro environment. Output: `Sonic_3_AIR_DS.nds`.

This package is source code and has not been compiled or tested on hardware.
