# Mobile build using GitHub Actions

1. Create a GitHub repository and upload/extract all files from this project into it.
2. Open the repository's Actions tab.
3. Select "Build NDS" and press "Run workflow" (or wait for push build).
4. When it finishes successfully, open the workflow run, then download the artifact named `Sonic_3_AIR_DS`.

This produces a test NDS file, not the Sonic 3 A.I.R. engine/game port.
